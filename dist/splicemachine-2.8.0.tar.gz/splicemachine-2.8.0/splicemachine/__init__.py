class SpliceMachineException(Exception):
    pass
